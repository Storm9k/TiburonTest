--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "TiburonTestDB";
--
-- Name: TiburonTestDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "TiburonTestDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE "TiburonTestDB" OWNER TO postgres;

\connect "TiburonTestDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Answers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Answers" (
    "ID" smallint NOT NULL,
    "AText" character varying(500) NOT NULL,
    "QuestionID" smallint NOT NULL,
    "IsTrue" boolean
);


ALTER TABLE public."Answers" OWNER TO postgres;

--
-- Name: Answer_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Answer_ID_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Answer_ID_seq" OWNER TO postgres;

--
-- Name: Answer_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Answer_ID_seq" OWNED BY public."Answers"."ID";


--
-- Name: Answer_QuestionID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Answer_QuestionID_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Answer_QuestionID_seq" OWNER TO postgres;

--
-- Name: Answer_QuestionID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Answer_QuestionID_seq" OWNED BY public."Answers"."QuestionID";


--
-- Name: Interviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Interviews" (
    "ID" integer NOT NULL,
    "Username" character varying(100) NOT NULL
);


ALTER TABLE public."Interviews" OWNER TO postgres;

--
-- Name: Interview_ID _seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Interview_ID _seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Interview_ID _seq" OWNER TO postgres;

--
-- Name: Interview_ID _seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Interview_ID _seq" OWNED BY public."Interviews"."ID";


--
-- Name: Questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Questions" (
    "ID" smallint NOT NULL,
    "QText" character varying(500) NOT NULL,
    "SurveyID" integer NOT NULL
);


ALTER TABLE public."Questions" OWNER TO postgres;

--
-- Name: Questions_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Questions_ID_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Questions_ID_seq" OWNER TO postgres;

--
-- Name: Questions_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Questions_ID_seq" OWNED BY public."Questions"."ID";


--
-- Name: Questions_SurveyID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Questions_SurveyID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Questions_SurveyID_seq" OWNER TO postgres;

--
-- Name: Questions_SurveyID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Questions_SurveyID_seq" OWNED BY public."Questions"."SurveyID";


--
-- Name: Results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Results" (
    "ID" integer NOT NULL,
    "InterviewID" integer NOT NULL,
    "AnswerID" smallint NOT NULL
);


ALTER TABLE public."Results" OWNER TO postgres;

--
-- Name: Results_AnswerID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Results_AnswerID_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Results_AnswerID_seq" OWNER TO postgres;

--
-- Name: Results_AnswerID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Results_AnswerID_seq" OWNED BY public."Results"."AnswerID";


--
-- Name: Results_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Results_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Results_ID_seq" OWNER TO postgres;

--
-- Name: Results_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Results_ID_seq" OWNED BY public."Results"."ID";


--
-- Name: Results_InterviewID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Results_InterviewID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Results_InterviewID_seq" OWNER TO postgres;

--
-- Name: Results_InterviewID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Results_InterviewID_seq" OWNED BY public."Results"."InterviewID";


--
-- Name: Surveys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Surveys" (
    "ID" integer NOT NULL,
    "Name" character varying(300) NOT NULL,
    "Description" character varying(500) NOT NULL
);


ALTER TABLE public."Surveys" OWNER TO postgres;

--
-- Name: Survey_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Survey_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Survey_ID_seq" OWNER TO postgres;

--
-- Name: Survey_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Survey_ID_seq" OWNED BY public."Surveys"."ID";


--
-- Name: Answers ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answers" ALTER COLUMN "ID" SET DEFAULT nextval('public."Answer_ID_seq"'::regclass);


--
-- Name: Answers QuestionID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answers" ALTER COLUMN "QuestionID" SET DEFAULT nextval('public."Answer_QuestionID_seq"'::regclass);


--
-- Name: Interviews ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Interviews" ALTER COLUMN "ID" SET DEFAULT nextval('public."Interview_ID _seq"'::regclass);


--
-- Name: Questions ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions" ALTER COLUMN "ID" SET DEFAULT nextval('public."Questions_ID_seq"'::regclass);


--
-- Name: Questions SurveyID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions" ALTER COLUMN "SurveyID" SET DEFAULT nextval('public."Questions_SurveyID_seq"'::regclass);


--
-- Name: Results ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Results" ALTER COLUMN "ID" SET DEFAULT nextval('public."Results_ID_seq"'::regclass);


--
-- Name: Results InterviewID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Results" ALTER COLUMN "InterviewID" SET DEFAULT nextval('public."Results_InterviewID_seq"'::regclass);


--
-- Name: Results AnswerID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Results" ALTER COLUMN "AnswerID" SET DEFAULT nextval('public."Results_AnswerID_seq"'::regclass);


--
-- Name: Surveys ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Surveys" ALTER COLUMN "ID" SET DEFAULT nextval('public."Survey_ID_seq"'::regclass);


--
-- Data for Name: Answers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Answers" ("ID", "AText", "QuestionID", "IsTrue") FROM stdin;
\.
COPY public."Answers" ("ID", "AText", "QuestionID", "IsTrue") FROM '$$PATH$$/3043.dat';

--
-- Data for Name: Interviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Interviews" ("ID", "Username") FROM stdin;
\.
COPY public."Interviews" ("ID", "Username") FROM '$$PATH$$/3045.dat';

--
-- Data for Name: Questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Questions" ("ID", "QText", "SurveyID") FROM stdin;
\.
COPY public."Questions" ("ID", "QText", "SurveyID") FROM '$$PATH$$/3040.dat';

--
-- Data for Name: Results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Results" ("ID", "InterviewID", "AnswerID") FROM stdin;
\.
COPY public."Results" ("ID", "InterviewID", "AnswerID") FROM '$$PATH$$/3051.dat';

--
-- Data for Name: Surveys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Surveys" ("ID", "Name", "Description") FROM stdin;
\.
COPY public."Surveys" ("ID", "Name", "Description") FROM '$$PATH$$/3039.dat';

--
-- Name: Answer_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Answer_ID_seq"', 1, false);


--
-- Name: Answer_QuestionID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Answer_QuestionID_seq"', 1, false);


--
-- Name: Interview_ID _seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Interview_ID _seq"', 1, true);


--
-- Name: Questions_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Questions_ID_seq"', 1, false);


--
-- Name: Questions_SurveyID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Questions_SurveyID_seq"', 1, false);


--
-- Name: Results_AnswerID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Results_AnswerID_seq"', 1, false);


--
-- Name: Results_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Results_ID_seq"', 10, true);


--
-- Name: Results_InterviewID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Results_InterviewID_seq"', 1, false);


--
-- Name: Survey_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Survey_ID_seq"', 1, false);


--
-- Name: Answers Answer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answers"
    ADD CONSTRAINT "Answer_pkey" PRIMARY KEY ("ID");


--
-- Name: Interviews Interview_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Interviews"
    ADD CONSTRAINT "Interview_pkey" PRIMARY KEY ("ID");


--
-- Name: Questions Questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions"
    ADD CONSTRAINT "Questions_pkey" PRIMARY KEY ("ID");


--
-- Name: Results Results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Results"
    ADD CONSTRAINT "Results_pkey" PRIMARY KEY ("ID");


--
-- Name: Surveys Survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Surveys"
    ADD CONSTRAINT "Survey_pkey" PRIMARY KEY ("ID");


--
-- Name: Results Answer_ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Results"
    ADD CONSTRAINT "Answer_ID" FOREIGN KEY ("AnswerID") REFERENCES public."Answers"("ID") NOT VALID;


--
-- Name: Results Interview_ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Results"
    ADD CONSTRAINT "Interview_ID" FOREIGN KEY ("InterviewID") REFERENCES public."Interviews"("ID") NOT VALID;


--
-- Name: Answers Question_ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Answers"
    ADD CONSTRAINT "Question_ID" FOREIGN KEY ("QuestionID") REFERENCES public."Questions"("ID") NOT VALID;


--
-- Name: Questions Survey_ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Questions"
    ADD CONSTRAINT "Survey_ID" FOREIGN KEY ("SurveyID") REFERENCES public."Surveys"("ID") NOT VALID;


--
-- PostgreSQL database dump complete
--

